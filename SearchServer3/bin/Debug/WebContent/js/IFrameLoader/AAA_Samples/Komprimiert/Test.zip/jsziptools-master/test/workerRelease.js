importScripts(
    '../jsziptools.js',
    'workerBody.js'
);